﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MainMVC.Migrations
{
    public partial class newdefault : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
